//  Add Your logic here
function myLogic() {
  var myCandidate = document.getElementById("inText")
  if (myCandidate) {
     if (isPalindrome(myCandidate.value)) {
        return myCandidate.value + " is a palindrome."
     }
  }
  return `Hey you can\'t fool a fooler!  ${myCandidate.value} is not a palindrome.`;
}

//  Add listeners on page load
function onLoadPage() {
document.querySelector("#start").innerText = "Enter a palindrome candidate";

//  add enter-key listener
var stubKey = document.querySelector("input");

stubKey.addEventListener("keyup", (event)  => {
  if ( event.keyCode === 13 )
    document.querySelector("#result").innerText = myLogic();
  return false;
  });

//
//  add button listener
//
var stubBtn = document.querySelector("#go-stub");

stubBtn.addEventListener("click", (event)  => {
  document.querySelector("#result").innerText = myLogic();
  });
}

//
//  Add helper functions or stub routines for fake data
//
function isPalindrome(w) {
                  
  var candidate = filterCandidate(w.toUpperCase()); 

  // compare two bytes from both ends  - moving to the middle
  for ( var x=0,y=candidate.length-1 ;  y!=x && y-1!=x ;  x++, y-- ) {
    if ( candidate[x] != candidate[y] ) { 
      return false;
    }
  }
  return true; 
}

//
//  Add helper functions or stub routines for fake data
//
function filterCandidate(w) {
  var patt = /[A-Z]+/g;
  var result = w.match(patt);
  for ( var x=1;  x < result.length; x++ ) {
    result[0] += result[x];
  }
  return result[0];
}
