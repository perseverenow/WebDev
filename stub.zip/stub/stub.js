//  Add Your logic here
function myLogic() {
  var newState;
  var myState = document.getElementById("inText")
  if (myState) {
     newState = myState.value.toUpperCase();
     if (validateState(newState)) {
        return newState + " is valid."
     }
  }
  return "Error";
}

//  Add listeners on page load
function onLoadPage() {
document.querySelector("#start").innerText = "Enter a 2-digit state code";

//  add enter-key listener
var stubKey = document.querySelector("input");

stubKey.addEventListener("keyup", (event)  => {
  if ( event.keyCode === 13 )
    document.querySelector("#result").innerText = myLogic();
  return false;
  });

//  add button listener
var stubBtn = document.querySelector("#go-stub");

stubBtn.addEventListener("click", (event)  => {
  document.querySelector("#result").innerText = myLogic();
  });
}

//  Add helper functions or stub routines for fake data
function validateState(s) {

  var   validState;
  const stateArr = 
		 [ 'AZ', 'IL', 'CA', 'AK', 'AR', 'CO', 'CT', 'DE', 'FL', 'GA', 
                   'HI', 'ID', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MA', 'MI', 
                   'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 
                   'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 
                   'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'];
 
  if ( stateArr.indexOf( s ) >= 0 ) {
    validState = true;
  }
  else {
    validState = false;
  }
  return validState; 
}
