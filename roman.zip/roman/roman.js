//
// This is your main helper function
//
function convertToRoman(num) {

 var str = num.toString(); /* make this number a string */
 var roman = [];

 // process string digit by digit - convert each digit to a number
 for (var i=0; i<str.length; i++)
    // push each converted digit into an array
    roman.push( getRoman(parseInt(str[i]), (str.length-1)-i));
 return roman.join('');
}

//
// another helper function for conversion lookup
//
function getRoman(n, power) {
  var result = 
  [  
    ['','','',''],
    ['I','X','L','M'],
    ['II','XX','LL','MM'],
    ['III','XXX','LLL','MMM'],
    ['IV','XL','CD', 'MMMM'],
    ['V','L', 'D', 'MMMMM'],
    ['VI','LX', 'DC'],
    ['VII','LXX', 'DCC'],
    ['VIII','LXXX', 'DCCC'],
    ['IX','XC', 'CM']
  ];
  return result[n][power];
}


//  Add Your Mainline logic here
function myLogic() {
  var myState = document.getElementById("inText") /* get entry field */
  if (myState) {
     return convertToRoman(myState.value);  /* convert to Roman */
  }
  return "Error";
}



//  Add listeners on page load
function onLoadPage() {
document.querySelector("#start").innerText = 
                   "Enter a number to convert to Roman Numerals";

//  add enter-key listener
var stubKey = document.querySelector("input");

stubKey.addEventListener("keyup", (event)  => {
  if ( event.keyCode === 13 )
    document.querySelector("#result").innerText = myLogic();
  });

//  add button listener
var stubBtn = document.querySelector("#go-stub");

stubBtn.addEventListener("click", (event)  => {
  document.querySelector("#result").innerText = myLogic();
  });
}

